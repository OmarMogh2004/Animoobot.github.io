// Popover of Bootstrap
$(function () {
$('[data-toggle="tooltip"]').tooltip()
})





